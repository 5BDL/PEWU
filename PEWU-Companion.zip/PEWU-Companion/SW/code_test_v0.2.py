import ipaddress
import ssl
import wifi
import socketpool
import adafruit_requests
import terminalio
from adafruit_magtag.magtag import MagTag
import time
from adafruit_io.adafruit_io import IO_HTTP, AdafruitIO_RequestError

## Hardware Definition

magtag = MagTag()
buttons = magtag.peripherals.buttons

# Get Secrets File
try:
    from secrets import secrets
except ImportError:
    print("WiFi secrets are kept in secrets.py, please add them there!")
    raise

print("My MAC addr:", [hex(i) for i in wifi.radio.mac_address])

# WiFi Connect

print("Avaliable WiFi networks:")
for network in wifi.radio.start_scanning_networks():
    print("\t%s\t\tRSSI: %d\tChannel: %d" % (str(network.ssid, "utf-8"),
            network.rssi, network.channel))
wifi.radio.stop_scanning_networks()

print("Connecting to %s"%secrets["ssid"])

# Build try & retry logic as part of the connection flow - need graceful exit to continue

while not esp.is_connected:
    try:
        esp.connect_AP(secrets["ssid"], secrets["password"])
    except RuntimeError as e:
        print("could not connect to AP, retrying: ", e)
        continue
print("Connected to", str(esp.ssid, "utf-8"), "\tRSSI:", esp.rssi)

wifi.radio.connect(secrets["ssid"], secrets["password"])
print(print("Connected to %s!"%secrets["ssid"]))
print("My IP address is", wifi.radio.ipv4_address)

#pool = socketpool.SocketPool(wifi.radio)
#requests = adafruit_requests.Session(pool, ssl.create_default_context())

# Connect to IO

aio_username = secrets["aio_username"]
aio_key = secrets["aio_key"]
location = secrets.get("timezone", None)
TIME_URL = "https://io.adafruit.com/api/v2/%s/integrations/time/strftime?x-aio-key=%s" % (aio_username, aio_key)
TIME_URL += "&fmt=%25Y-%25m-%25d+%25H%3A%25M%3A%25S.%25L+%25j+%25u+%25z+%25Z"
# Initialize an Adafruit IO HTTP API object
pool = socketpool.SocketPool(wifi.radio)
requests = adafruit_requests.Session(pool, ssl.create_default_context())
io = IO_HTTP(aio_username, aio_key, requests)

'''
#TEST

# Create a new 'circuitpython' feed with a description
print("Creating new Adafruit IO feed...")
feed = io.create_new_feed("circuitpython", "a Adafruit IO CircuitPython feed")

# List a specified feed
print("Retrieving new Adafruit IO feed...")
specified_feed = io.get_feed("circuitpython")
print(specified_feed)

# Delete a specified feed by feed key
print("Deleting feed...")
io.delete_feed(specified_feed["key"])
print("Feed deleted!")
'''


# Get Patch Feeds
pewu_food = io.get_feed("5bdl.pewu-food")
pewu_water = io.get_feed("5bdl.pewu-water")

print("PEWU Food = %s and PEWU Water = %s" % (pewu_food, pewu_water))

## Software Definition

button_colors = ((255, 0, 0), (255, 150, 0), (0, 255, 255), (180, 0, 255))
button_tones = (1047, 1318, 1568, 2093)
timestamp = time.monotonic()

magtag.add_text(
    text_font="fonts/COFFE&MILK-32.bdf",
    text_position=(
        5,
        (magtag.graphics.display.height // 2) - 1,
        20,
    ),
    text_anchor_point=(0, 1),
    text_scale=1,
)

magtag.set_text("Welcome to 5-BDL")

'''
print("Fetching text from", TIME_URL)
response = requests.get(TIME_URL)
print("-" * 40)
print(response.text)
print("-" * 40)
'''

## Main Loop

while True:
    for i, b in enumerate(buttons):
        if not b.value:
            print("Button %c pressed" % chr((ord("A") + i)))
            magtag.peripherals.neopixel_disable = False
            magtag.peripherals.neopixels.fill(button_colors[i])
            magtag.peripherals.play_tone(button_tones[i], 0.25)
            break
    else:
        magtag.peripherals.neopixel_disable = True
    time.sleep(0.01)
